from flask import Blueprint

forum = Blueprint('forum', __name__)

