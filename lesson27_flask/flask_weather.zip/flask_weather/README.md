# Flask weather
Simple weather app for students
